from colorama import Fore
from colorama import init



def main():
    init()
    print(Fore.RED + 'Hello')


if __name__ == '__main__':
    main()